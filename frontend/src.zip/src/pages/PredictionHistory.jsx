import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import api from "../services/api";

const PredictionHistory = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const response = await api.get(
          "/predictions"
        );

        setHistory(response.data);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            "Failed to load prediction history"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  if (loading) {
    return <h2>Loading history...</h2>;
  }

  return (
    <div className="page">
      <Link to="/dashboard">
        ← Dashboard
      </Link>

      <h1>📋 Prediction History</h1>

      {error && (
        <div className="error">
          {error}
        </div>
      )}

      {!error && history.length === 0 && (
        <p>
          No predictions found. Start by scanning a
          plant.
        </p>
      )}

      {history.map((item) => (
        <div
          className="history-card"
          key={item.id}
        >
          <h2>
            🌿 {item.plant?.commonName}
          </h2>

          <p>
            <strong>Scientific Name:</strong>{" "}
            {item.plant?.scientificName}
          </p>

          <p>
            <strong>Confidence:</strong>{" "}
            {(item.confidence * 100).toFixed(2)}%
          </p>

          {item.imageUrl && (
            <img
              src={item.imageUrl}
              alt={item.plant?.commonName}
              width="200"
            />
          )}

          <p>
            <strong>Date:</strong>{" "}
            {new Date(
              item.predictedAt
            ).toLocaleString()}
          </p>
        </div>
      ))}
    </div>
  );
};

export default PredictionHistory;