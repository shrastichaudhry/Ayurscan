import { useEffect, useState } from "react";
import {
  Link,
  useParams,
} from "react-router-dom";

import api from "../services/api";

const PlantDetails = () => {
  const { id } = useParams();

  const [plant, setPlant] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchPlant = async () => {
      try {
        const response = await api.get(
          `/plants/${id}`
        );

        setPlant(response.data);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            "Failed to load plant"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchPlant();
  }, [id]);

  if (loading) {
    return <h2>Loading plant...</h2>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  if (!plant) {
    return <h2>Plant not found</h2>;
  }

  return (
    <div className="page">
      <Link to="/plants">← Back to Plants</Link>

      <h1>🌿 {plant.commonName}</h1>

      <p>
        <strong>Scientific Name:</strong>{" "}
        {plant.scientificName}
      </p>

      <p>
        <strong>Family:</strong>{" "}
        {plant.family}
      </p>

      {plant.medicinalUses?.length > 0 && (
        <>
          <h2>Medicinal Uses</h2>

          {plant.medicinalUses.map((use) => (
            <div
              className="use-card"
              key={use.id}
            >
              <h3>{use.title}</h3>

              <p>
                <strong>Plant Part:</strong>{" "}
                {use.plantPart}
              </p>

              <p>{use.description}</p>

              <small>
                Source: {use.sourceName}
              </small>
            </div>
          ))}
        </>
      )}

      <h2>Precautions</h2>

      <p>{plant.precautions}</p>

      <p>
        <strong>Note:</strong> These are
        traditional Ayurvedic uses and are not a
        substitute for professional medical advice.
      </p>
    </div>
  );
};

export default PlantDetails;