import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";

const Plants = () => {
  const [plants, setPlants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchPlants = async () => {
      try {
        const response = await api.get("/plants");
        setPlants(response.data);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            "Failed to load plants"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchPlants();
  }, []);

  if (loading) {
    return <h2>Loading plants...</h2>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  return (
    <div className="page">
      <h1>🌿 AyurScan Plants</h1>

      <Link to="/dashboard">← Dashboard</Link>

      <div className="plant-grid">
        {plants.map((plant) => (
          <div className="plant-card" key={plant.id}>
            <h2>{plant.commonName}</h2>

            <p>
              <strong>Scientific Name:</strong>{" "}
              {plant.scientificName}
            </p>

            <p>
              <strong>Family:</strong>{" "}
              {plant.family}
            </p>

            <Link to={`/plants/${plant.id}`}>
              View Details →
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Plants;