import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import api from "../services/api";

const Favorites = () => {
  const [favorites, setFavorites] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const fetchFavorites = async () => {
    try {
      const response = await api.get(
        "/favorites"
      );

      setFavorites(response.data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to load favorites"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFavorites();
  }, []);

  const removeFavorite = async (plantId) => {
    try {
      await api.delete(
        `/favorites/${plantId}`
      );

      setFavorites((current) =>
        current.filter(
          (item) =>
            item.plant?.id !== plantId
        )
      );
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to remove favorite"
      );
    }
  };

  if (loading) {
    return <h2>Loading favorites...</h2>;
  }

  return (
    <div className="page">
      <Link to="/dashboard">
        ← Dashboard
      </Link>

      <h1>❤️ Favorite Plants</h1>

      {error && (
        <div className="error">
          {error}
        </div>
      )}

      {!error && favorites.length === 0 && (
        <p>
          You haven't added any plants to
          favorites yet.
        </p>
      )}

      <div className="plant-grid">
        {favorites.map((favorite) => {
          const plant = favorite.plant;

          if (!plant) return null;

          return (
            <div
              className="plant-card"
              key={plant.id}
            >
              <h2>
                🌿 {plant.commonName}
              </h2>

              <p>
                <strong>
                  Scientific Name:
                </strong>{" "}
                {plant.scientificName}
              </p>

              <p>
                <strong>Family:</strong>{" "}
                {plant.family}
              </p>

              <Link
                to={`/plants/${plant.id}`}
              >
                View Details
              </Link>

              <br />

              <button
                onClick={() =>
                  removeFavorite(plant.id)
                }
              >
                Remove Favorite
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Favorites;