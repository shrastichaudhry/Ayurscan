import { useState } from "react";
import { Link } from "react-router-dom";

import api from "../services/api";
import CameraScanner from "../components/CameraScanner";

const Predict = () => {
  const [file, setFile] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showCamera, setShowCamera] = useState(false);

  const predictPlant = async (selectedFile) => {
    if (!selectedFile) {
      setError("Please select a plant image");
      return;
    }

    setFile(selectedFile);
    setError("");
    setResult(null);
    setLoading(true);

    try {
      const formData = new FormData();

      formData.append("file", selectedFile);

      const response = await api.post(
        "/predictions/predict",
        formData,
      );

      setResult(response.data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Prediction failed"
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await predictPlant(file);
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];

    if (!selectedFile) {
      return;
    }

    setFile(selectedFile);
    setResult(null);
    setError("");
  };

  const handleCameraCapture = async (capturedFile) => {
    setShowCamera(false);

    await predictPlant(capturedFile);
  };

  return (
    <div className="page">

      <Link to="/dashboard">
        ← Dashboard
      </Link>

      <div className="predict-header">

        <div>
          <span className="camera-label">
            AYURSCAN AI
          </span>

          <h1>📷 Identify a Plant</h1>

          <p>
            Scan or upload a plant image to identify
            its medicinal information.
          </p>
        </div>

      </div>

      <div className="predict-options">

        {/* CAMERA BUTTON */}

        <button
          type="button"
          className="camera-scan-button"
          onClick={() => {
            setError("");
            setShowCamera(true);
          }}
          disabled={loading}
        >
          <span className="camera-button-icon">
            📷
          </span>

          <span>
            <strong>Scan with Camera</strong>
            <small>
              Use your device camera
            </small>
          </span>
        </button>


        {/* FILE UPLOAD */}

        <div className="upload-option">

          <div className="upload-icon">
            📁
          </div>

          <div>
            <strong>Upload Image</strong>

            <small>
              JPG, PNG or WebP
            </small>
          </div>

          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handleFileChange}
          />

        </div>

      </div>


      {/* SELECTED FILE */}

      {file && (
        <div className="selected-file">

          <span>🌿</span>

          <div>
            <strong>
              {file.name}
            </strong>

            <small>
              Ready for identification
            </small>
          </div>

        </div>
      )}


      {/* IDENTIFY BUTTON */}

      <form onSubmit={handleSubmit}>

        <button
          type="submit"
          className="identify-button"
          disabled={loading || !file}
        >
          {loading
            ? "🔬 Analyzing Plant..."
            : "🌿 Identify Plant"}
        </button>

      </form>


      {/* ERROR */}

      {error && (
        <div className="error">
          {error}
        </div>
      )}


      {/* RESULT */}

      {result && (
        <div className="result-card">

          <h2>
            🌿 Prediction Result
          </h2>

          <h3>
            {result.prediction}
          </h3>

          <p>
            <strong>
              Confidence:
            </strong>{" "}
            {(result.confidence * 100).toFixed(2)}%
          </p>


          {result.plant && (
            <>

              <p>
                <strong>
                  Scientific Name:
                </strong>{" "}
                {result.plant.scientificName}
              </p>

              <p>
                <strong>
                  Family:
                </strong>{" "}
                {result.plant.family}
              </p>


              <h3>
                Medicinal Uses
              </h3>


              {result.plant.medicinalUses?.map(
                (use) => (
                  <div
                    className="use-card"
                    key={use.id}
                  >

                    <strong>
                      {use.title}
                    </strong>

                    <p>
                      Plant Part:{" "}
                      {use.plantPart}
                    </p>

                    <p>
                      {use.description}
                    </p>

                    <small>
                      Source:{" "}
                      {use.sourceName}
                    </small>

                  </div>
                )
              )}


              <h3>
                Precautions
              </h3>

              <p>
                {result.plant.precautions}
              </p>

            </>
          )}

        </div>
      )}


      {/* CAMERA */}

      {showCamera && (
        <CameraScanner
          onCapture={handleCameraCapture}
          onClose={() => setShowCamera(false)}
        />
      )}

    </div>
  );
};

export default Predict;